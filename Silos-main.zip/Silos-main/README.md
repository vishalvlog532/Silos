# Silos
A platform which can accurately match these ServiceSuppliers, who wants to work on innovative ideas and IdeaPreneurs, who  have innovative ideas together to build a better team which can work more efficiently increasing the productivity as well as  employee satisfaction in an enterprise. 
